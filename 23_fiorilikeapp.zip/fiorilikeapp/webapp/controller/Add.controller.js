sap.ui.define(
    ["am/hr/payroll/controller/BaseController",
     "sap/ui/model/json/JSONModel",
     "sap/m/MessageBox",
     "sap/m/MessageToast"
    ],
    function(BaseController, JSONModel, MessageBox, MessageToast) {
        return BaseController.extend("am.hr.payroll.controller.Add", {
            
            oLocalModel: null,
            onInit: function(){

                this.oLocalModel = new JSONModel();
                this.oLocalModel.setData(
                    {
                        "prodData": {
                                            "PRODUCT_ID": "",
                                            "TYPE_CODE": "PR",
                                            "CATEGORY": "Notebooks",
                                            "NAME": "",
                                            "DESCRIPTION": "",
                                            "SUPPLIER_ID": "0100000051",
                                            "SUPPLIER_NAME": "TECUM",
                                            "TAX_TARIF_CODE": "1 ",
                                            "MEASURE_UNIT": "EA",
                                            "PRICE": "0.00",
                                            "CURRENCY_CODE": "USD",
                                            "DIM_UNIT": "CM",
                                            "PRODUCT_PIC_URL": "/sap/public/bc/NWDEMO_MODEL/IMAGES/AM-1010.jpg"
                                    }
                    }
                );
                this.getView().setModel(this.oLocalModel, "rosa");

                //Step 3: get the odata model object
                this.oDataModel = this.getOwnerComponent().getModel();
            },
            onClear: function(){
                this.oLocalModel.setProperty("/prodData",{
                                            "PRODUCT_ID": "",
                                            "TYPE_CODE": "PR",
                                            "CATEGORY": "Notebooks",
                                            "NAME": "",
                                            "DESCRIPTION": "",
                                            "SUPPLIER_ID": "0100000051",
                                            "SUPPLIER_NAME": "TECUM",
                                            "TAX_TARIF_CODE": "1 ",
                                            "MEASURE_UNIT": "EA",
                                            "PRICE": "0.00",
                                            "CURRENCY_CODE": "USD",
                                            "DIM_UNIT": "CM",
                                            "PRODUCT_PIC_URL": "/sap/public/bc/NWDEMO_MODEL/IMAGES/AM-1010.jpg"
                                    }
                );
                this.setMode("Create");
            },
            mode: "Create",
            setMode: function(sMode){
                this.mode = sMode;
                if (this.mode === "Update") {
                    this.getView().byId("prodId").setEnabled(false);
                    this.getView().byId("idCreate").setText("Update");
                }else{
                    this.getView().byId("prodId").setEnabled(true);
                    this.getView().byId("idCreate").setText("Create");                    
                }
            },
            onEnter: function(oEvent){
                var that = this;
                //Step 1: read the value user type in product id
                var sVal = oEvent.getParameter("value");
                //Step 2: send call to backend to load data
                this.oDataModel.read("/ProductSet('" + sVal + "')", {
                    success: function(data){
                        that.oLocalModel.setProperty("/prodData",data);
                        //send our controller object also to the method which will be set as this
                        that.setMode("Update").bind(that);
                    }
                });



            },
            onCreate: function(){
                //Step 1: get the data which needs to be sent to sap
                var payload = this.oLocalModel.getProperty("/prodData");
                //Step 2: if you want to validate you can
                if (!payload.PRODUCT_ID) {
                    MessageBox.error("Woha, please pass product id");
                    return "";   
                }

                if (this.mode === "Update") {
                    //Step 3: use odata to call sap to create data
                    this.oDataModel.update("/ProductSet('" + payload.PRODUCT_ID + "')", payload, {
                        success: function(){
                            MessageToast.show("Wallah! the product is now updated in sap");
                        },
                        error: function(oError){
                            //access error message from response
                            var oMessages = JSON.parse(oError.responseText);
                            MessageBox.error("Oops! there was an issue More Details : " + oMessages.error.innererror.errordetails[0].message);
                        }
                    });
                }else{
                    //Step 3: use odata to call sap to create data
                    this.oDataModel.create("/ProductSet", payload, {
                        success: function(){
                            MessageToast.show("Wallah! the product is now created in sap");
                        },
                        error: function(oError){
                            //access error message from response
                            var oMessages = JSON.parse(oError.responseText);
                            MessageBox.error("Oops! there was an issue More Details : " + oMessages.error.innererror.errordetails[0].message);
                        }
                    });
                }
                
                
            }


        });
    }
);